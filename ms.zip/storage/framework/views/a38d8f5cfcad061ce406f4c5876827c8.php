<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Ventas</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; }
        h1, h3 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: center; }
        .total { font-size: 18px; font-weight: bold; margin-top: 20px; text-align: right; }
        button { margin-top: 30px; padding: 10px 20px; font-size: 16px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Reporte de Ventas</h1>
    <h3>Desde: <?php echo e($desde); ?> — Hasta: <?php echo e($hasta); ?></h3>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($factura->id); ?></td>
                    <td><?php echo e($factura->cliente->nombre); ?></td>
                    <td><?php echo e($factura->fecha); ?></td>
                    <td>$<?php echo e(number_format($factura->total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No hay facturas en ese rango de fechas</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="total">
        Total vendido: $<?php echo e(number_format($totalVentas, 2)); ?>

    </div>

    <div style="text-align: center;">
        <button onclick="window.print()">🖨️ Imprimir</button>
    </div>
</body>
</html>
<?php /**PATH /home/rodrigo/ms/resources/views/facturas/reporte.blade.php ENDPATH**/ ?>