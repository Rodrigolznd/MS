<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Gestión de Productos</h1>

    <form action="<?php echo e(route('productos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="codigo" placeholder="Código">
        <input type="number" name="stock" placeholder="Stock">
        <input type="text" name="precio" placeholder="Precio">
        <input type="text" name="descripcion" placeholder="Descripción">
        <input type="text" name="imagen" placeholder="URL Imagen">
        <input type="text" name="categoria" placeholder="Categoría">
        <select name="estado">
            <option value="activo">Activo</option>
            <option value="inactivo">Inactivo</option>
        </select>
        <button type="submit">Registrar</button>
    </form>

    <table border="1" cellpadding="5">
        <thead>
            <tr>
                <th>Nombre</th><th>Descripción</th><th>Precio</th><th>Categoría</th><th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->precio); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td>
                    <form action="<?php echo e(route('productos.destroy', $producto)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit">Eliminar</button>
                    </form>

                    <form action="<?php echo e(route('productos.update', $producto)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>">
                        <input type="text" name="descripcion" value="<?php echo e($producto->descripcion); ?>">
                        <input type="number" name="precio" value="<?php echo e($producto->precio); ?>">
                        <input type="text" name="categoria" value="<?php echo e($producto->categoria); ?>">
                        <button type="submit">Editar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rodrigo/ms/resources/views/productos/index.blade.php ENDPATH**/ ?>