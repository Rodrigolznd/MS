<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura #<?php echo e($factura->id); ?></title>
    <style>
        body { font-family: Arial; margin: 30px; }
        .factura-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid #000; background: #fff; }
        h1, h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        .total { text-align: right; margin-top: 20px; font-size: 18px; font-weight: bold; }
        .acciones { text-align: center; margin-top: 30px; }
        .acciones button { padding: 10px 20px; font-size: 16px; }
    </style>
</head>
<body>
    <div class="factura-box">
        <h1>Factura</h1>
        <h2>#<?php echo e($factura->id); ?></h2>

        <p><strong>Cliente:</strong> <?php echo e($factura->cliente->nombre); ?></p>
        <p><strong>Fecha:</strong> <?php echo e($factura->fecha); ?></p>

        <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $factura->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subtotal = $detalle->cantidad * $detalle->precio_unitario;
                    $total += $subtotal;
                ?>
                <tr>
                    <td><?php echo e($detalle->producto->nombre); ?></td>
                    <td><?php echo e($detalle->cantidad); ?></td>
                    <td>$<?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                    <td>$<?php echo e(number_format($subtotal, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>


        <div class="total">
            Total: $<?php echo e(number_format($total, 2)); ?>

        </div>

        <div class="acciones">
            <button onclick="window.print()">🖨️ Imprimir Factura</button>
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/rodrigo/ms/resources/views/facturas/factura_generada.blade.php ENDPATH**/ ?>