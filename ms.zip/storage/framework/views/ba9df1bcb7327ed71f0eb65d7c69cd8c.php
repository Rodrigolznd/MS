<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }
        .modal-content {
            position: absolute;
            top: 100px;
            left: 50%;
            transform: translateX(-50%);
            width: 400px;
            background-color: rgb(195, 195, 195);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }
        .modal-header {
            display: flex;
            justify-content: flex-end;
        }
        .close {
            font-size: 24px;
            cursor: pointer;
            color: #333;
        }
        .modal-content label, .modal-content input, .modal-content select, .modal-content textarea {
            display: block;
            width: calc(100% - 20px);
            margin-bottom: 10px;
            padding: 8px;
        }
        .modal-content .buttons {
            display: flex;
            justify-content: space-between;
        }

        .modal-content .buttons button {
            padding: 10px;
        }
    </style>
</head>
<body>
<?php if(session('success')): ?>
<script>
    alert("<?php echo e(session('success')); ?>");
</script>
<?php endif; ?>
<header>
        <div class="menu">
            <div class="logo-container">
                <a href="<?php echo e(route('dashboard.admin')); ?>">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="logo">
                </a>
            </div>
            <div>
            <nav>
                <a href="<?php echo e(route('admin.usuarios')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                    <img src="<?php echo e(asset('img/registro.png')); ?>" alt="Usuarios" class="icon">
                    <span class="title">Usuarios</span>
                </a>
                <a href="<?php echo e(route('clientes.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                    <img src="<?php echo e(asset('img/clientes.png')); ?>" alt="Clientes" class="icon">
                    <span class="title">Clientes</span>
                </a>
                <a href="<?php echo e(route('inventario.index')); ?>" class="link" style="background-color: rgb(255, 255, 255);">
                    <img src="<?php echo e(asset('img/inventario.png')); ?>" alt="Inventario" class="icon">
                    <span class="title">Inventario</span>
                </a>
                <a href="<?php echo e(route('facturas.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                    <img src="<?php echo e(asset('img/factura.png')); ?>" alt="Facturación" class="icon">
                    <span class="title">Facturación</span>
                </a>
                <span>👤 <?php echo e(Auth::user()->username); ?></span>
                <span>: <?php echo e(ucfirst(Auth::user()->rol)); ?> </span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background: none; border: none; color: blue; cursor: pointer;">
                        Cerrar sesión
                    </button>
                </form>
            </nav>
            </div>
        </div>
    </header>

<div class="main-container">
    <div class="acciones">
        <a href="#" id="openModalBtn">
            Registrar Producto
            <img src="<?php echo e(asset('img/registrarproducto.png')); ?>" width="30" alt="registrar">
        </a>
        <div class="separator"></div>
        <a href="javascript:void(0);" onclick="openReporteModal()">
            Generar reporte de ventas
            <img src="<?php echo e(asset('img/generarreporte.png')); ?>" width="30" alt="generarreporte">
        </a>
        <div class="separator"></div>
        <form method="GET" action="<?php echo e(route('inventario.index')); ?>" style="align-items: center; gap: 4px; margin-left: 10px;">
        <input type="text" name="buscar" placeholder="Buscar producto" value="<?php echo e(request('buscar')); ?>" style="padding: 8px; border: 2px solid #000; border-radius: 4px;">
            <button type="submit" style="background: none; border: none; cursor: pointer;" title="Buscar producto">
                <img src="<?php echo e(asset('img/lupa.png')); ?>" width="25" alt="buscar_producto" class="img-lupa">
            </button>
        </form>
        </div>

    <!-- Tabla de productos -->
    <table class="custom-table">
        <thead>
        <tr>
            <th>Nombre</th>
            <th>Código</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Categoría</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->codigo); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td>$<?php echo e(number_format($producto->precio, 2)); ?></td>
                <td><?php echo e($producto->categoria); ?></td>
                <td><?php echo e($producto->estado); ?></td>
                <td>
                    <!-- Botón Editar Producto -->
                    <button onclick="document.getElementById('modalEditar<?php echo e($producto->id); ?>').style.display='block'" style="background: none; border: none;">
                        <img src="<?php echo e(asset('img/editar.png')); ?>" alt="Editar" width="24">
                    </button>

                    <!-- Botón Eliminar Producto -->
                    <form action="<?php echo e(route('inventario.destroy', $producto->id)); ?>" method="POST" style="display:inline" onsubmit="return confirm('¿Eliminar este producto?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="background: none; border: none;">
                            <img src="<?php echo e(asset('img/eliminar.png')); ?>" alt="Eliminar" width="24">
                        </button>
                    </form>
                </td>
            </tr>

            <!-- Modal Editar -->
            <div id="modalEditar<?php echo e($producto->id); ?>" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <span class="close" onclick="document.getElementById('modalEditar<?php echo e($producto->id); ?>').style.display='none'">&times;</span>
                    </div>
                    <h2>Editar Producto</h2>
                    <form action="<?php echo e(route('inventario.update', $producto->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <label>Nombre</label>
                        <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>" required>

                        <label>Código</label>
                        <input type="text" name="codigo" value="<?php echo e($producto->codigo); ?>" required>

                        <label>Stock</label>
                        <input type="number" name="stock" value="<?php echo e($producto->stock); ?>" required>

                        <label>Precio</label>
                        <input type="number" step="0.01" name="precio" value="<?php echo e($producto->precio); ?>" required>

                        <label>Descripción</label>
                        <textarea name="descripcion" required><?php echo e($producto->descripcion); ?></textarea>

                        <label>Categoría</label>
                        <select name="categoria" required>
                            <option value="Electronica" <?php if($producto->categoria=='Electronica'): ?> selected <?php endif; ?>>Electrónica</option>
                            <option value="Muebles" <?php if($producto->categoria=='Muebles'): ?> selected <?php endif; ?>>Muebles</option>
                        </select>

                        <label>Estado</label>
                        <select name="estado" required>
                            <option value="activo" <?php if($producto->estado=='activo'): ?> selected <?php endif; ?>>Activo</option>
                            <option value="inactivo" <?php if($producto->estado=='inactivo'): ?> selected <?php endif; ?>>Inactivo</option>
                        </select>

                        <label>Imagen</label>
                        <input type="file" name="imagen">

                        <div class="buttons">
                            <button type="submit">Guardar cambios</button>
                            <button type="button" onclick="document.getElementById('modalEditar<?php echo e($producto->id); ?>').style.display='none'">Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal Registrar Producto -->
<div id="registerModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <span class="close" id="closeModalBtn">&times;</span>
        </div>
        <h2>Registrar Producto</h2>
        <form action="<?php echo e(route('inventario.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label>Nombre</label>
            <input type="text" name="nombre" required>

            <label>Código</label>
            <input type="text" name="codigo" required>

            <label>Stock</label>
            <input type="number" name="stock" value="0" required>

            <label>Precio</label>
            <input type="number" step="0.01" name="precio" required>

            <label>Descripción</label>
            <textarea name="descripcion" required></textarea>

            <label>Categoría</label>
            <select name="categoria" required>
                <option value="Electronica">Electrónica</option>
                <option value="Muebles">Muebles</option>
            </select>

            <label>Estado</label>
            <select name="estado" required>
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
            </select>

            <label>Imagen</label>
            <input type="file" name="imagen">

            <div class="buttons">
                <button type="submit">Registrar</button>
                <button type="button" id="cancelModalBtn">Cancelar</button>
            </div>
        </form>
    </div>
</div>
<!-- Modal para generar reporte -->
        <div id="reporteModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                <span class="close" id="closeReporteModalBtn">&times;</span>
                </div>
                <h2>Generar reporte de ventas</h2>
                <form method="GET" action="<?php echo e(route('reporte.ventas')); ?>" target="_blank">
                <label for="fecha_inicio">Fecha de Inicio:</label>
            <input type="date" id="fecha_inicio" name="fecha_inicio" required>
            <label for="fecha_fin">Fecha de Fin:</label>
            <input type="date" id="fecha_fin" name="fecha_fin" required>
                <br><br>
                 <div class="buttons">
                    <button type="submit">Generar reporte</button>
                    <button type="button" onclick="closeReporteModal()">Cancelar</button>
                 </div>
            </form>
            </div>
        </div>
    </div>
<footer>
    © <?php echo e(date('Y')); ?> Lorman S.A.S
</footer>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const modal = document.getElementById("registerModal");
        document.getElementById("openModalBtn").onclick = function (e) {
            e.preventDefault();
            modal.style.display = "block";
        }
        document.getElementById("closeModalBtn").onclick = () => modal.style.display = "none";
        document.getElementById("cancelModalBtn").onclick = () => modal.style.display = "none";
        window.onclick = function (event) {
            if (event.target === modal) modal.style.display = "none";
        }
    });
    function openReporteModal() {
        document.getElementById('reporteModal').style.display = 'block';
    }

    function closeReporteModal() {
        document.getElementById('reporteModal').style.display = 'none';
    }

    document.addEventListener("DOMContentLoaded", function () {
        const modal = document.getElementById('reporteModal');
        const closeBtn = document.getElementById('closeReporteModalBtn');

        // Cierra al hacer clic en la X
        closeBtn.addEventListener('click', closeReporteModal);

        // Cierra al hacer clic fuera del contenido del modal
        window.addEventListener('click', function (event) {
            if (event.target === modal) {
                closeReporteModal();
            }
        });
    });
</script>
</body>
</html>
<?php /**PATH /home/rodrigo/Documentos/ms/resources/views/inventario/index.blade.php ENDPATH**/ ?>