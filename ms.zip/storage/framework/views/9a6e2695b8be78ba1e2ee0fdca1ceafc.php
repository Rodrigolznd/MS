<?php
    use Illuminate\Support\Facades\Auth;
?>

<?php if(!Auth::check() || Auth::user()->rol !== 'admin'): ?>
    <?php abort(403, 'Acceso denegado: solo administradores'); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
            /* Estilos para el modal */
            .modal {
            display: none; /* Oculto por defecto */
            position: fixed;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            }


            .modal-content {
                position: absolute;
                top: 100px; /* Ajusta según la posición deseada */
                left: 50%;
                transform: translateX(-50%);
                width: 400px; /* Ancho del formulario */
                background-color: rgb(195, 195, 195); /* Fondo gris */
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
                position: relative; /* Necesario para posicionar el botón de cierre */
            }

            .modal-header {
                display: flex;
                justify-content: flex-end;
            }

            .close {
                font-size: 24px;
                cursor: pointer;
                color: #333;
            }

            .modal-content label {
                display: block;
                margin-bottom: 10px;
            }

            .modal-content input,
            .modal-content select {
                width: calc(100% - 20px);
                padding: 8px;
                margin-bottom: 10px;
            }

            .modal-content .buttons {
                display: flex;
                justify-content: space-between;
            }

            .modal-content .buttons button {
                padding: 10px;
            }
    </style>
</head>
<body>
    <header>
        <div class="menu">
        <div class="logo-container">
            <a href="<?php echo e(route('dashboard.admin')); ?>">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="logo">
            </a>
        </div>
            <nav>
                <a href="<?php echo e(route('admin.usuarios')); ?>" class="link" style="background-color: rgb(255, 255, 255);">
                    <img src="<?php echo e(asset('img/registro.png')); ?>" alt="Usuarios" class="icon">
                    <span class="title">Usuarios</span>
                </a>
                <a href="<?php echo e(route('inventario.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                    <img src="<?php echo e(asset('img/inventario.png')); ?>" alt="Inventario" class="icon">
                    <span class="title">Inventario</span>
                </a>
                <a href="<?php echo e(route('facturas.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                    <img src="<?php echo e(asset('img/factura.png')); ?>" alt="Facturación" class="icon">
                    <span class="title">Facturación</span>
                </a>
                <span>👤 <?php echo e(Auth::user()->name); ?></span>
                <span>: <?php echo e(ucfirst(Auth::user()->rol)); ?> </span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background: none; border: none; color: blue; cursor: pointer;">
                        Cerrar sesión
                    </button>
                </form>
            </nav>
        </div>
    </header>

    <div class="main-container">
        <div class="acciones">
            <a href="#" id="openModalBtn">
                Registrar Usuario <img src="<?php echo e(asset('img/registrar.png')); ?>" width="30" alt="Registrar">
            </a>
            <div class="separator"></div>
            <form method="GET" action="<?php echo e(route('admin.usuarios')); ?>" style="align-items: center; gap: 4px; margin-left: 10px; display: flex;">
                <input type="text" name="buscar" placeholder="Buscar usuario" value="<?php echo e(request('buscar')); ?>" style="padding: 8px; border: 2px solid #000; border-radius: 4px;">
                <button type="submit" style="background: none; border: none; cursor: pointer;" title="Buscar usuario">
                    <img src="<?php echo e(asset('img/lupa.png')); ?>" width="25" alt="buscar_usuario" class="img-lupa">
                </button>
            </form>
        </div>

<!-- Tabla -->
<table class="custom-table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Usuario</th>
            <th>Correo</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Fecha Registro</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="fila-<?php echo e($usuario->id); ?>">
                <td><?php echo e($usuario->name); ?></td>
                <td><?php echo e($usuario->username); ?></td>
                <td><?php echo e($usuario->email); ?></td>
                <td><?php echo e($usuario->rol); ?></td>
                <td><?php echo e($usuario->estado ? 'Activo' : 'Inactivo'); ?></td>
                <td><?php echo e($usuario->created_at->format('Y-m-d')); ?></td>
                <td>
                    <!-- Editar -->
                    <button onclick="abrirModal(<?php echo e($usuario); ?>)" style="background: none; border: none;">
                        <img src="<?php echo e(asset('img/editar.png')); ?>" alt="Editar" width="24">
                    </button>
                    <!-- Eliminar -->
                    <button onclick="eliminarUsuario(<?php echo e($usuario->id); ?>)" style="background: none; border: none;">
                        <img src="<?php echo e(asset('img/eliminar.png')); ?>" alt="Eliminar" width="24">
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    </div>

    <div id="registerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="close" id="closeModalBtn">&times;</span>
            </div>
            <h2>Registrar Usuario</h2>
            <form action="<?php echo e(route('admin.usuarios.registrar')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="name">Nombre completo:</label>
                <input type="text" name="name" required>

                <label for="username">Nombre de usuario:</label>
                <input type="text" name="username" required>

                <label for="email">Correo electrónico:</label>
                <input type="email" name="email" required>

                <!-- Password -->
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'password','value' => __('Contraseña')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Contraseña'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'password','class' => 'block mt-1 w-full','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password','class' => 'block mt-1 w-full','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>

                <!-- Confirm Password -->
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'password_confirmation','value' => __('Confirmar Contraseña')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password_confirmation','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Confirmar Contraseña'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'password_confirmation','class' => 'block mt-1 w-full','type' => 'password','name' => 'password_confirmation','required' => true,'autocomplete' => 'new-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password_confirmation','class' => 'block mt-1 w-full','type' => 'password','name' => 'password_confirmation','required' => true,'autocomplete' => 'new-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password_confirmation'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password_confirmation')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                
                <label for="rol">Rol:</label>
                <select name="rol" required>
                    <option value="">Seleccione</option>
                    <option value="admin">Administrador</option>
                    <option value="usuario">Usuario</option>
                    <option value="cliente">Cliente</option>
                </select>

                <label for="estado">Estado:</label>
                <select name="estado" required>
                    <option value="1">Activo</option>
                    <option value="0">Inactivo</option>
                </select>

                <div class="buttons">
                    <button type="submit">Registrar</button>
                    <button type="button" id="cancelModalBtn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal -->
<div id="modalEditar" class="modal">
<div class="modal-content">
<div class="modal-header">
<span class="close" id="closeEditarBtn">&times;</span>
    </div>
        <h2>Editar Usuario</h2>
    <form id="formEditar">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="id" id="edit-id">
        <label>Nombre</label>
        <input type="text" id="edit-name" name="name"><br>
        <label>Username</label>
        <input type="text" id="edit-username" name="username"><br>
        <label>Email</label>
        <input type="email" id="edit-email" name="email"><br>
        <label>Rol</label>
        <select id="edit-rol" name="rol">
            <option value="admin">Admin</option>
            <option value="usuario">Usuario</option>
            <option value="cliente">Cliente</option>
        </select><br>
        <label>Estado</label>
        <select id="edit-estado" name="estado">
            <option value="1">Activo</option>
            <option value="0">Inactivo</option>
        </select><br><br>
        <div class="buttons">
        <button type="submit">Guardar</button>
        <button type="button" onclick="cerrarModal()">Cancelar</button>
        </div>
    </form>
    </div>
    </div>


    <footer>
        © <?php echo e(date('Y')); ?> Lorman S.A.S
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const modal = document.getElementById("registerModal");
            const openBtn = document.getElementById("openModalBtn");
            const closeBtn = document.getElementById("closeModalBtn");
            const cancelBtn = document.getElementById("cancelModalBtn");

            openBtn.addEventListener("click", function (e) {
                e.preventDefault();
                modal.style.display = "block";
            });

            closeBtn.addEventListener("click", () => modal.style.display = "none");
            cancelBtn.addEventListener("click", () => modal.style.display = "none");

            window.onclick = function (event) {
                if (event.target == modal) modal.style.display = "none";
            }
        });
    function eliminarUsuario(id) {
        if (!confirm('¿Deseas eliminar este usuario?')) return;

        fetch(`/admin/usuarios/${id}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        })
        .then(res => res.ok ? document.getElementById(`fila-${id}`).remove() : alert('Error al eliminar'));
    }

    function abrirModal(usuario) {
        document.getElementById('edit-id').value = usuario.id;
        document.getElementById('edit-name').value = usuario.name;
        document.getElementById('edit-username').value = usuario.username;
        document.getElementById('edit-email').value = usuario.email;
        document.getElementById('edit-rol').value = usuario.rol;
        document.getElementById('edit-estado').value = usuario.estado ? 1 : 0;
        document.getElementById('modalEditar').style.display = 'block';
    }

    function cerrarModal() {
        document.getElementById('modalEditar').style.display = 'none';
    }

    document.getElementById('formEditar').addEventListener('submit', function(e) {
        e.preventDefault();
        const id = document.getElementById('edit-id').value;
        const formData = new FormData(this);

        fetch(`/admin/usuarios/${id}`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'X-HTTP-Method-Override': 'PUT'
            },
            body: formData
        }).then(res => {
            if (res.ok) {
                alert('Usuario actualizado');
                location.reload();
            } else {
                alert('Error al actualizar');
            }
        });
    });
    document.addEventListener("DOMContentLoaded", function () {
    // Referencias para el modal de editar
    const modalEditar = document.getElementById("modalEditar");
    const closeEditarBtn = document.getElementById("closeEditarBtn");

    closeEditarBtn.addEventListener("click", () => modalEditar.style.display = "none");

    });
    </script>
</body>
</html>
<?php /**PATH /home/rodrigo/ms/resources/views/dashboard/admin_usuarios.blade.php ENDPATH**/ ?>