<?php
    use Illuminate\Support\Facades\Auth;
?>

<?php if(!Auth::check() || Auth::user()->rol !== 'admin'): ?>
    <?php abort(403, 'Acceso denegado: solo administradores'); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador</title>
    
    <!-- ✅ Ruta correcta al CSS desde /public/css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>
    <header>
        <div class="menu">
            <div class="logo-container">
                <a href="<?php echo e(route('dashboard.admin')); ?>">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="logo">
                </a>
            </div>
            <div>
                <nav>
                    <div>
                    <a href="<?php echo e(route('admin.usuarios')); ?>" class="link" id="registro-link" style="background-color: rgb(192, 192, 192);">
                        <img src="<?php echo e(asset('img/registro.png')); ?>" alt="Registro" class="icon">
                        <span class="title">Usuarios</span>
                    </a>
                    </div>
                    <a href="<?php echo e(route('inventario.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                        <img src="<?php echo e(asset('img/inventario.png')); ?>" alt="Inventario" class="icon">
                        <span class="title">Inventario</span>
                    </a>
                    <a href="<?php echo e(route('facturas.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                        <img src="<?php echo e(asset('img/factura.png')); ?>" alt="Facturación" class="icon">
                        <span class="title">Facturación</span>
                    </a>
                    <span>👤 <?php echo e(Auth::user()->name); ?></span>
                    <span>: <?php echo e(ucfirst(Auth::user()->rol)); ?></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="background: none; border: none; color: blue; cursor: pointer;">
                            Cerrar sesión
                        </button>
                    </form>
                </nav>
            </div>
        </div>
    </header>

    <h4>Minimizing System</h4>

    <footer>
        © <?php echo e(date('Y')); ?> Lorman S.A.S
    </footer>
</body>
</html>
<?php /**PATH /home/rodrigo/ms/resources/views/dashboard/admin.blade.php ENDPATH**/ ?>