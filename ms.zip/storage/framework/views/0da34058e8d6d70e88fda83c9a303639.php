<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facturación</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
        .main-container {
            border: 2px solid black; /* Borde negro alrededor del contenedor */
            margin: 20px auto;
            width: 70%;
            height: 70px; /* Ajusta la altura del contenedor */
            overflow-y: unset; /* Habilita el scroll vertical */
            background-color: #f0f0f0; /* Fondo gris claro */
            padding: 10px;
        }
        /* Estilos para el modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro semi-transparente */
        }

        .modal-content {
            position: absolute;
            top: 100px; /* Ajusta según la posición deseada */
            left: 50%;
            transform: translateX(-50%);
            width: 400px; /* Ancho del formulario */
            background-color: rgb(195, 195, 195); /* Fondo gris */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            position: relative; /* Necesario para posicionar el botón de cierre */
        }

        .modal-header {
            display: flex;
            justify-content: flex-end;
        }

        .close {
            font-size: 24px;
            cursor: pointer;
            color: #333;
        }

        .modal-content label {
            display: block;
            margin-bottom: 10px;
        }

        .modal-content input,
        .modal-content select {
            width: calc(100% - 20px);
            padding: 8px;
            margin-bottom: 10px;
        }

        .modal-content .buttons {
            display: flex;
            justify-content: space-between;
        }

        .modal-content .buttons button {
            padding: 10px;
    }
    </style>
</head>
<body>
    <header>
        <div class="menu">
            <div class="logo-container">
                <a href="<?php echo e(route('dashboard.admin')); ?>">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="logo">
                </a>
            </div>
            <div>
                <nav>
                    <a href="<?php echo e(route('admin.usuarios')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                        <img src="<?php echo e(asset('img/registro.png')); ?>" alt="Registro" class="icon">
                        <span class="title">Usuarios</span>
                    </a>
                    <a href="<?php echo e(route('inventario.index')); ?>" class="link" style="background-color: rgb(192, 192, 192);">
                        <img src="<?php echo e(asset('img/inventario.png')); ?>" alt="Inventario" class="icon">
                        <span class="title">Inventario</span>
                    </a>
                    <a href="<?php echo e(route('facturas.index')); ?>" class="link" style="background-color: white;">
                        <img src="<?php echo e(asset('img/factura.png')); ?>" alt="Facturación" class="icon">
                        <span class="title">Facturación</span>
                    </a>
                    <span>👤 <?php echo e(Auth::user()->name); ?></span>
                    <span>: <?php echo e(ucfirst(Auth::user()->rol)); ?></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="background: none; border: none; color: blue; cursor: pointer;">
                            Cerrar sesión
                        </button>
                    </form>
                </nav>
            </div>
        </div>
    </header>
    <div class="main-container">
        <?php if(session('success')): ?>
            <script>alert("<?php echo e(session('success')); ?>");</script>
        <?php endif; ?>

        <div class="acciones">
            <a href="#" id="openModalBtn">
                Generar Factura
                <img src="<?php echo e(asset('img/generarfactura.png')); ?>" width="30" alt="Generar">
            </a>
        </div>
    </div>

    <!-- Modal de Generación de Factura -->
    <div id="registerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="close" id="closeModalBtn">&times;</span>
            </div>
            <h2>Generar Factura</h2>
            <form action="<?php echo e(route('facturas.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="cliente_id">Cliente:</label>
                <select name="cliente_id" required>
                    <option value="">-- Selecciona un cliente --</option>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label for="fecha">Fecha:</label>
                <input type="date" name="fecha" required>

                <div id="productos-container">
                    <div class="producto-item">
                        <select name="productos[0][id]" required>
                            <option value="">-- Producto --</option>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?> - $<?php echo e($producto->precio); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="number" name="productos[0][cantidad]" placeholder="Cantidad" min="1" required>
                    </div>
                </div>

                <button type="button" onclick="agregarProducto()">Agregar otro producto</button>

                <div class="buttons" style="margin-top: 15px;">
                    <button type="submit">Generar Factura</button>
                    <button type="button" id="cancelModalBtn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    <footer>
        © <?php echo e(date('Y')); ?> Lorman S.A.S
    </footer>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const modal = document.getElementById("registerModal");
            const openModalBtn = document.getElementById("openModalBtn");
            const closeModalBtn = document.getElementById("closeModalBtn");
            const cancelModalBtn = document.getElementById("cancelModalBtn");

            openModalBtn.onclick = function (e) {
                e.preventDefault();
                modal.style.display = "block";
            };

            closeModalBtn.onclick = () => modal.style.display = "none";
            cancelModalBtn.onclick = () => modal.style.display = "none";

            window.onclick = function (event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            };
        });

        let index = 1;
        function agregarProducto() {
            const container = document.getElementById('productos-container');
            const item = document.createElement('div');
            item.className = 'producto-item';
            item.innerHTML = `
                <select name="productos[${index}][id]" required>
                    <option value="">-- Producto --</option>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?> - $<?php echo e($producto->precio); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="number" name="productos[${index}][cantidad]" placeholder="Cantidad" min="1" required>
            `;
            container.appendChild(item);
            index++;
        }
    </script>
</body>
</html><?php /**PATH /home/rodrigo/ms/resources/views/facturas/index.blade.php ENDPATH**/ ?>