<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            position: absolute;
            top: 100px;
            left: 50%;
            transform: translateX(-50%);
            width: 400px;
            background-color: rgb(195, 195, 195);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: flex-end;
        }

        .close {
            font-size: 24px;
            cursor: pointer;
            color: #333;
        }

        .modal-content label {
            display: block;
            margin-bottom: 10px;
        }

        .modal-content input,
        .modal-content select {
            width: calc(100% - 20px);
            padding: 8px;
            margin-bottom: 10px;
        }

        .modal-content .buttons {
            display: flex;
            justify-content: space-between;
        }

        .modal-content .buttons button {
            padding: 10px;
        }

        .acciones {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 15px;
        }

        .acciones a {
            background-color: #cfcfcf;
            padding: 8px 12px;
            border-radius: 6px;
            text-decoration: none;
            color: black;
            font-weight: bold;
        }

        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .custom-table th, .custom-table td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: center;
        }

        footer {
            margin-top: 30px;
            text-align: center;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <h1>Clientes</h1>

        <div class="acciones">
            <a href="#" id="openModalBtn">
                Registrar Cliente <img src="<?php echo e(asset('img/registrar.png')); ?>" width="30" alt="Registrar">
            </a>

            <form method="GET" action="<?php echo e(route('clientes.index')); ?>" style="display: flex; gap: 5px; align-items: center;">
                <input type="text" name="buscar" placeholder="Buscar cliente" value="<?php echo e(request('buscar')); ?>" style="padding: 8px; border: 2px solid #000; border-radius: 4px;">
                <button type="submit" style="background: none; border: none; cursor: pointer;" title="Buscar cliente">
                    <img src="<?php echo e(asset('img/lupa.png')); ?>" width="25" alt="buscar_cliente">
                </button>
            </form>
        </div>

        <?php if(session('success')): ?>
            <p><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <table class="custom-table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Estado</th>
                    <th>Fecha Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="fila-<?php echo e($cliente->id); ?>">
                        <td><?php echo e($cliente->nombre); ?></td>
                        <td><?php echo e($cliente->email); ?></td>
                        <td><?php echo e($cliente->telefono); ?></td>
                        <td><?php echo e($cliente->direccion); ?></td>
                        <td><?php echo e($cliente->estado ? 'Activo' : 'Inactivo'); ?></td>
                        <td><?php echo e($cliente->created_at->format('Y-m-d')); ?></td>
                        <td>
                            <button onclick="abrirModalEditar(<?php echo e($cliente); ?>)" style="background: none; border: none;">
                                <img src="<?php echo e(asset('img/editar.png')); ?>" alt="Editar" width="24">
                            </button>
                            <button onclick="eliminarCliente(<?php echo e($cliente->id); ?>)" style="background: none; border: none;">
                                <img src="<?php echo e(asset('img/eliminar.png')); ?>" alt="Eliminar" width="24">
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Modal Registrar -->
    <div id="registerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="close" id="closeModalBtn">&times;</span>
            </div>
            <h2>Registrar Cliente</h2>
            <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label>Nombre</label>
                <input type="text" name="nombre" required>
                <label>Email</label>
                <input type="email" name="email">
                <label>Teléfono</label>
                <input type="text" name="telefono">
                <label>Dirección</label>
                <input type="text" name="direccion">
                <label>Estado</label>
                <select name="estado">
                    <option value="1">Activo</option>
                    <option value="0">Inactivo</option>
                </select>
                <div class="buttons">
                    <button type="submit">Registrar</button>
                    <button type="button" id="cancelModalBtn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar -->
    <div id="modalEditar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="close" id="closeEditarBtn">&times;</span>
            </div>
            <h2>Editar Cliente</h2>
            <form id="formEditar">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" id="edit-id" name="id">
                <label>Nombre</label>
                <input type="text" id="edit-nombre" name="nombre">
                <label>Email</label>
                <input type="email" id="edit-email" name="email">
                <label>Teléfono</label>
                <input type="text" id="edit-telefono" name="telefono">
                <label>Dirección</label>
                <input type="text" id="edit-direccion" name="direccion">
                <label>Estado</label>
                <select id="edit-estado" name="estado">
                    <option value="1">Activo</option>
                    <option value="0">Inactivo</option>
                </select>
                <div class="buttons">
                    <button type="submit">Guardar</button>
                    <button type="button" onclick="cerrarModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        © <?php echo e(date('Y')); ?> Lorman S.A.S
    </footer>

    <script>
        // Abrir/Cerrar modal registrar
        document.getElementById('openModalBtn').onclick = () => document.getElementById('registerModal').style.display = 'block';
        document.getElementById('closeModalBtn').onclick = () => document.getElementById('registerModal').style.display = 'none';
        document.getElementById('cancelModalBtn').onclick = () => document.getElementById('registerModal').style.display = 'none';

        // Abrir modal editar con datos
        function abrirModalEditar(cliente) {
            document.getElementById('edit-id').value = cliente.id;
            document.getElementById('edit-nombre').value = cliente.nombre;
            document.getElementById('edit-email').value = cliente.email;
            document.getElementById('edit-telefono').value = cliente.telefono;
            document.getElementById('edit-direccion').value = cliente.direccion;
            document.getElementById('edit-estado').value = cliente.estado;
            document.getElementById('modalEditar').style.display = 'block';
        }

        document.getElementById('closeEditarBtn').onclick = cerrarModal;
        function cerrarModal() {
            document.getElementById('modalEditar').style.display = 'none';
        }

        // Enviar edición
        document.getElementById('formEditar').addEventListener('submit', function(e) {
            e.preventDefault();
            const id = document.getElementById('edit-id').value;
            const formData = new FormData(this);

            fetch(`/clientes/${id}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'X-HTTP-Method-Override': 'PUT'
                },
                body: formData
            }).then(res => {
                if (res.ok) {
                    alert('Cliente actualizado');
                    location.reload();
                } else {
                    alert('Error al actualizar');
                }
            });
        });

        // Eliminar cliente
        function eliminarCliente(id) {
            if (!confirm('¿Deseas eliminar este cliente?')) return;

            fetch(`/clientes/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(res => {
                if (res.ok) {
                    document.getElementById(`fila-${id}`).remove();
                } else {
                    alert('Error al eliminar');
                }
            });
        }
    </script>
</body>
</html>
<?php /**PATH /home/rodrigo/ms/resources/views/clientes/index.blade.php ENDPATH**/ ?>